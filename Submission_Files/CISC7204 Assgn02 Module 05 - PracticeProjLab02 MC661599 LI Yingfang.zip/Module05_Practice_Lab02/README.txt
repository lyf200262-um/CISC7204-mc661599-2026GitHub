PAIR WORK DECLARATION
----------------------------------------------------------------------
Course          : CISC7204 Data Science and Data Visualization
Coursework item : Assignment 02 - Group (2 Pax) Work
Class           : Class K
Pair            : Pair 14
Member 1        : LI Yingfang (MC661599)
Member 2        : LI Tianhao (MC663312)

Declaration of partnership.  This archive is submitted jointly by the two
members of Pair 14.  In line with the course policy on pair work in
Assignment 02, both members submit the same set of assignment artifacts at
their own submission links and personal forums, and both members
contributed to the work presented here.  The partnership was registered at
the Forum of Pair Partner Registration (Assignment 02) under the HOME
UMMoodle site of CISC7204.

Student  : LI Yingfang
ID       : MC661599
Course   : CISC7204 Data Visualization, University of Macau
Archive  : CISC7204 Assgn02 Module 05 - PracticeProjLab02 MC661599 LI Yingfang.zip

Contents : Python source of the Australia Wildfire dashboard, plus
           the screen shots posted in the personal forum.

The archive is self-contained.  The data set is downloaded by the
code itself, so nothing else has to be added to the folder
before running it.

1. WHAT IS IN THIS ARCHIVE
----------------------------------------------------------------------

Dash_wildfire.py is the Australia Wildfire Dashboard.  It implements
TASK 2.2 to TASK 2.5 of the practice project:

  TASK 2.2  radio items for the region (New South Wales / Western
            Australia, default NSW) and a dropdown for the year
            (default 2005), placed under the first inner division
  TASK 2.3  two empty divisions (ids 'plot1' and 'plot2') that receive
            the two graphs
  TASK 2.4  the @app.callback decorator with two outputs and two inputs
  TASK 2.5  the callback body, which filters the data frame by region and
            year and returns two dcc.Graph objects:

              plot1  monthly average estimated fire area  (px.line)
              plot2  average count of pixels for presumed vegetation
                     fires  (px.bar)

Each chart title embeds the selected region and year, so the screen shots
show the title updating together with the data.

Folder layout:

  Module05_Practice_Lab02/
  |-- README.txt                                              this file
  |-- Dash_wildfire.py                                            4.0 KB
  `-- Screen Shots/
        7 PNG files, numbered 01 to 07

  9 files in total.

2. HOW TO RUN
----------------------------------------------------------------------

Open a terminal in the folder that holds the .py file(s):

    cd Module05_Practice_Lab02
    python Dash_wildfire.py

Dash prints the address in the terminal.  Open a browser at

    http://127.0.0.1:8050

and stop the server with Ctrl+C when you are done.

Requirements: Python 3.10 or newer.  Tested with

    Python 3.14.6 / dash 4.4.1 / pandas 3.0.3 / plotly 6.7.0

Install the three packages with one command:

    pip install dash pandas plotly

Any recent Dash (2.x or newer) will also work: the code only uses
stable APIs (dash.Dash, dcc, html, dash.dependencies.Input/Output).

3. DATA
----------------------------------------------------------------------

No CSV is shipped inside this archive on purpose.  Each app downloads
its data set when it starts, from the IBM Skills Network course
storage:

    https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/Historical_Wildfires.csv

An internet connection is therefore needed on the first run; the
download takes a few seconds.  If the machine is offline, save the
CSV next to the .py file and point the pd.read_csv(...) line at the
local copy.

4. SCREEN SHOTS
----------------------------------------------------------------------

Screen Shots/ holds the 7 images that were posted in the personal
forum for this module.  The file names carry a running step number
(01, 02, ...), so the folder reads as a walk-through of the exercise:
source code, terminal output on port 8050, browser output, and the
interaction step.

They are included as evidence that the app actually ran.  They are
not needed in order to run it.

5. NOTES
----------------------------------------------------------------------

The year dropdown is populated from df.Year.unique() rather than from a
hard-coded list, so it always matches the years present in the data set.

Both graphs come out of one callback as a list of two dcc.Graph components.
The output divisions are created empty in the layout and filled only after
the user changes an input, which is the behaviour TASK 2.3 and TASK 2.5
ask for.

----------------------------------------------------------------------
Prepared by LI Tianhao (MC663312) for CISC7204 Assignment 02,
University of Macau.  Due 25 October 2026, 11:00 pm.
----------------------------------------------------------------------