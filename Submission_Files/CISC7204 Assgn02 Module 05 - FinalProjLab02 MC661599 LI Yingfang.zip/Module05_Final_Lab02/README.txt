PAIR WORK DECLARATION
----------------------------------------------------------------------
Course          : CISC7204 Data Science and Data Visualization
Coursework item : Assignment 02 - Group (2 Pax) Work
Class           : Class K
Pair            : Pair 14
Member 1        : LI Yingfang (MC661599)
Member 2        : LI Tianhao (MC663312)

Declaration of partnership.  This archive is submitted jointly by the two
members of Pair 14.  In line with the course policy on pair work in
Assignment 02, both members submit the same set of assignment artifacts at
their own submission links and personal forums, and both members
contributed to the work presented here.  The partnership was registered at
the Forum of Pair Partner Registration (Assignment 02) under the HOME
UMMoodle site of CISC7204.

Student  : LI Yingfang
ID       : MC661599
Course   : CISC7204 Data Visualization, University of Macau
Archive  : CISC7204 Assgn02 Module 05 - FinalProjLab02 MC661599 LI Yingfang.zip

Contents : Python source of the Automobile Sales Statistics
           dashboard, plus the screen shots posted in the
           personal forum.

The archive is self-contained.  The data set is downloaded by the
code itself, so nothing else has to be added to the folder
before running it.

1. WHAT IS IN THIS ARCHIVE
----------------------------------------------------------------------

DV0101EN-Final-Assign-Part-2-Questions.py is the Automobile Sales
Statistics Dashboard.  It implements TASK 2.1 to TASK 2.6 of the final
project:

  TASK 2.1  dashboard heading "Automobile Sales Statistics Dashboard"
  TASK 2.2  two dropdowns: report type (Yearly Statistics / Recession
            Period Statistics) and year (1980-2023)
  TASK 2.3  an output division laid out as a 2 x 2 grid
  TASK 2.4  two callbacks: one that disables the year dropdown unless
            "Yearly Statistics" is selected, and one that renders the
            chosen report
  TASK 2.5  the four recession charts: average automobile sales over the
            recession period, average vehicles sold by vehicle type,
            total expenditure share by vehicle type, and the effect of
            the unemployment rate on vehicle type and sales
  TASK 2.6  the four yearly charts: yearly sales for the whole period,
            total monthly sales, average vehicles sold by vehicle type in
            the selected year, and advertisement expenditure per vehicle

Two extra files are included because the lab instructions ask for them by
name:

  RecessionReportgraphs.png   the complete Recession Period report
  YearlyReportgraphs.png      the complete Yearly report

Both were saved with exactly those file names, as the lab text requires.

Folder layout:

  Module05_Final_Lab02/
  |-- README.txt                                              this file
  |-- DV0101EN-Final-Assign-Part-2-Questions.py                   9.8 KB
  |-- RecessionReportgraphs.png                                 101.5 KB
  |-- YearlyReportgraphs.png                                    166.0 KB
  `-- Screen Shots/
        14 PNG files, numbered 01 to 14

  18 files in total.

2. HOW TO RUN
----------------------------------------------------------------------

Open a terminal in the folder that holds the .py file(s):

    cd Module05_Final_Lab02
    python DV0101EN-Final-Assign-Part-2-Questions.py

Dash prints the address in the terminal.  Open a browser at

    http://127.0.0.1:8050

and stop the server with Ctrl+C when you are done.

Requirements: Python 3.10 or newer.  Tested with

    Python 3.14.6 / dash 4.4.1 / pandas 3.0.3 / plotly 6.7.0

Install the three packages with one command:

    pip install dash pandas plotly

Any recent Dash (2.x or newer) will also work: the code only uses
stable APIs (dash.Dash, dcc, html, dash.dependencies.Input/Output).

3. DATA
----------------------------------------------------------------------

No CSV is shipped inside this archive on purpose.  Each app downloads
its data set when it starts, from the IBM Skills Network course
storage:

    https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/d51iMGfp_t0QpO30Lym-dw/automobile-sales.csv

An internet connection is therefore needed on the first run; the
download takes a few seconds.  If the machine is offline, save the
CSV next to the .py file and point the pd.read_csv(...) line at the
local copy.

4. SCREEN SHOTS
----------------------------------------------------------------------

Screen Shots/ holds the 14 images that were posted in the personal
forum for this module.  The file names carry a running step number
(01, 02, ...), so the folder reads as a walk-through of the exercise:
source code, terminal output on port 8050, browser output, and the
interaction step.

They are included as evidence that the app actually ran.  They are
not needed in order to run it.

5. NOTES
----------------------------------------------------------------------

The script ends with app.run(debug=True) as required by the lab.  Debug
mode also prints every request in the terminal, which is what the last
screen shot (year 2020) is documenting.

The year dropdown stays disabled until "Yearly Statistics" is chosen: that
is the first callback of TASK 2.4.  The second callback returns a list of
four dcc.Graph objects, so the 2 x 2 grid is filled in one go.

The two PNG files are full-page captures of the two reports.  They are
static evidence and are not read by the script.

----------------------------------------------------------------------
Prepared by LI Tianhao (MC663312) for CISC7204 Assignment 02,
University of Macau.  Due 25 October 2026, 11:00 pm.
----------------------------------------------------------------------