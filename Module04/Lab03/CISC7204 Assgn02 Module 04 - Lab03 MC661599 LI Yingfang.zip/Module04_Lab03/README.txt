CISC7204 Assignment 02 - Module 04 Lab 03 - Dash Interactivity
======================================================================

Student  : LI Yingfang
ID       : MC661599
Course   : CISC7204 Data Visualization, University of Macau
Archive  : CISC7204 Assgn02 Module 04 - Lab03 MC661599 LI Yingfang.zip

Contents : Python source of the two Dash Interactivity apps, plus the
           screen shots posted in the personal forum.

The archive is self-contained.  The data set is downloaded by the
code itself, so nothing else has to be added to the folder
before running it.

1. WHAT IS IN THIS ARCHIVE
----------------------------------------------------------------------

Two scripts, each a self-contained Dash app:

  dash_interactivity.py
      A year dropdown (dcc.Dropdown) wired to one dcc.Graph through an
      @app.callback decorator.  Uses plotly.graph_objects to draw a line
      chart of "Month vs Average Flight Delay Time" for the chosen year.

  dash_interactivity_barplot.py
      The same callback pattern, but the graph is a plotly.express bar
      chart of "Total number of flights to the destination state split by
      reporting airline" for the chosen year.

The two scripts are the two halves of the same lab (line chart, then bar
chart), which is why the forum post shows both.

Folder layout:

  Module04_Lab03/
  |-- README.txt                                              this file
  |-- dash_interactivity.py                                       2.2 KB
  |-- dash_interactivity_barplot.py                               2.3 KB
  `-- Screen Shots/
        8 PNG files, numbered 01 to 08

  11 files in total.

2. HOW TO RUN
----------------------------------------------------------------------

Open a terminal in the folder that holds the .py file(s):

    cd Module04_Lab03
    python dash_interactivity.py

Dash prints the address in the terminal.  Open a browser at

    http://127.0.0.1:8050

and stop the server with Ctrl+C when you are done.

Requirements: Python 3.10 or newer.  Tested with

    Python 3.14.6 / dash 4.4.1 / pandas 3.0.3 / plotly 6.7.0

Install the three packages with one command:

    pip install dash pandas plotly

Any recent Dash (2.x or newer) will also work: the code only uses
stable APIs (dash.Dash, dcc, html, dash.dependencies.Input/Output).

3. DATA
----------------------------------------------------------------------

No CSV is shipped inside this archive on purpose.  Each app downloads
its data set when it starts, from the IBM Skills Network course
storage:

    https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv

An internet connection is therefore needed on the first run; the
download takes a few seconds.  If the machine is offline, save the
CSV next to the .py file and point the pd.read_csv(...) line at the
local copy.

4. SCREEN SHOTS
----------------------------------------------------------------------

Screen Shots/ holds the 8 images that were posted in the personal
forum for this module.  The file names carry a running step number
(01, 02, ...), so the folder reads as a walk-through of the exercise:
source code, terminal output on port 8050, browser output, and the
interaction step.

They are included as evidence that the app actually ran.  They are
not needed in order to run it.

5. NOTES
----------------------------------------------------------------------

Both scripts end with app.run() and therefore both listen on port 8050.
Run them ONE AT A TIME: start the first, look at it, press Ctrl+C, then
start the second.  To keep both running, change the last line of the
second script to  app.run(port=8051)  and open that port instead.

Each callback returns a single figure because each app has one output.
The multi-output pattern is introduced in the next lab.

----------------------------------------------------------------------
Prepared by LI Tianhao (MC663312) for CISC7204 Assignment 02,
University of Macau.  Due 25 October 2026, 11:00 pm.
----------------------------------------------------------------------