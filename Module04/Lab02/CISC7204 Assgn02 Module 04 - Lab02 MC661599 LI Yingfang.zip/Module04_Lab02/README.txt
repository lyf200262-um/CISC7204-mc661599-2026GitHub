CISC7204 Assignment 02 - Module 04 Lab 02 - Dash Basics
======================================================================

Student  : LI Yingfang
ID       : MC661599
Course   : CISC7204 Data Visualization, University of Macau
Archive  : CISC7204 Assgn02 Module 04 - Lab02 MC661599 LI Yingfang.zip

Contents : Python source of the Dash Basics app, plus the screen
           shots posted in the personal forum.

The archive is self-contained.  The data set is downloaded by the
code itself, so nothing else has to be added to the folder
before running it.

1. WHAT IS IN THIS ARCHIVE
----------------------------------------------------------------------

dash_basics.py builds the first Dash application of the module: one outer
html.Div holding an html.H1 title and a single dcc.Graph.  The graph is a
plotly.express pie chart of the distance-group proportion by number of
flights.  The exercise finishes by updating the browser-tab title and the
page heading, which is what the last screen shot shows.

Folder layout:

  Module04_Lab02/
  |-- README.txt                                              this file
  |-- dash_basics.py                                              1.6 KB
  `-- Screen Shots/
        5 PNG files, numbered 01 to 05

  7 files in total.

2. HOW TO RUN
----------------------------------------------------------------------

Open a terminal in the folder that holds the .py file(s):

    cd Module04_Lab02
    python dash_basics.py

Dash prints the address in the terminal.  Open a browser at

    http://127.0.0.1:8050

and stop the server with Ctrl+C when you are done.

Requirements: Python 3.10 or newer.  Tested with

    Python 3.14.6 / dash 4.4.1 / pandas 3.0.3 / plotly 6.7.0

Install the three packages with one command:

    pip install dash pandas plotly

Any recent Dash (2.x or newer) will also work: the code only uses
stable APIs (dash.Dash, dcc, html, dash.dependencies.Input/Output).

3. DATA
----------------------------------------------------------------------

No CSV is shipped inside this archive on purpose.  Each app downloads
its data set when it starts, from the IBM Skills Network course
storage:

    https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv

An internet connection is therefore needed on the first run; the
download takes a few seconds.  If the machine is offline, save the
CSV next to the .py file and point the pd.read_csv(...) line at the
local copy.

4. SCREEN SHOTS
----------------------------------------------------------------------

Screen Shots/ holds the 5 images that were posted in the personal
forum for this module.  The file names carry a running step number
(01, 02, ...), so the folder reads as a walk-through of the exercise:
source code, terminal output on port 8050, browser output, and the
interaction step.

They are included as evidence that the app actually ran.  They are
not needed in order to run it.

5. NOTES
----------------------------------------------------------------------

The layout is built from nested html.Div / html.H1 components instead of a
one-line figure, because the point of Lab 02 is the Dash component tree,
not the chart itself.

The app runs on the default port 8050 via app.run() at the end of the
script.  There is only one script here, so no port conflict is possible.

----------------------------------------------------------------------
Prepared by LI Tianhao (MC663312) for CISC7204 Assignment 02,
University of Macau.  Due 25 October 2026, 11:00 pm.
----------------------------------------------------------------------