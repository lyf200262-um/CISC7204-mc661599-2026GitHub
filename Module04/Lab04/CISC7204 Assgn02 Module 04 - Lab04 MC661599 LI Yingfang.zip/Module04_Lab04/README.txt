CISC7204 Assignment 02 - Module 04 Lab 04 - Flight Delay Dashboard
======================================================================

Student  : LI Yingfang
ID       : MC661599
Course   : CISC7204 Data Visualization, University of Macau
Archive  : CISC7204 Assgn02 Module 04 - Lab04 MC661599 LI Yingfang.zip

Contents : Python source of the two Flight Delay dashboards, plus the
           screen shots posted in the personal forum.

The archive is self-contained.  The data set is downloaded by the
code itself, so nothing else has to be added to the folder
before running it.

1. WHAT IS IN THIS ARCHIVE
----------------------------------------------------------------------

Two scripts, each a five-chart dashboard:

  flight_delay.py
      Dashboard title "Flight Delay Time Statistics".  A year input box
      (dcc.Input) drives one callback with FIVE outputs: carrier delay,
      weather delay, NAS delay, security delay and late-aircraft delay.
      Each is a plotly.express line chart averaged by month and coloured
      by reporting airline; the last chart is set to 65 percent width.

  flight_details.py
      The same five charts and the same multi-output callback, with the
      dashboard title renamed to "Flight Details Statistics Dashboard".

flight_delay.py is the multi-output exercise; flight_details.py is the
final iteration of it, so both are kept.

Folder layout:

  Module04_Lab04/
  |-- README.txt                                              this file
  |-- flight_delay.py                                             5.2 KB
  |-- flight_details.py                                           5.2 KB
  `-- Screen Shots/
        10 PNG files, numbered 01 to 10

  13 files in total.

2. HOW TO RUN
----------------------------------------------------------------------

Open a terminal in the folder that holds the .py file(s):

    cd Module04_Lab04
    python flight_delay.py

Dash prints the address in the terminal.  Open a browser at

    http://127.0.0.1:8050

and stop the server with Ctrl+C when you are done.

Requirements: Python 3.10 or newer.  Tested with

    Python 3.14.6 / dash 4.4.1 / pandas 3.0.3 / plotly 6.7.0

Install the three packages with one command:

    pip install dash pandas plotly

Any recent Dash (2.x or newer) will also work: the code only uses
stable APIs (dash.Dash, dcc, html, dash.dependencies.Input/Output).

3. DATA
----------------------------------------------------------------------

No CSV is shipped inside this archive on purpose.  Each app downloads
its data set when it starts, from the IBM Skills Network course
storage:

    https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv

An internet connection is therefore needed on the first run; the
download takes a few seconds.  If the machine is offline, save the
CSV next to the .py file and point the pd.read_csv(...) line at the
local copy.

4. SCREEN SHOTS
----------------------------------------------------------------------

Screen Shots/ holds the 10 images that were posted in the personal
forum for this module.  The file names carry a running step number
(01, 02, ...), so the folder reads as a walk-through of the exercise:
source code, terminal output on port 8050, browser output, and the
interaction step.

They are included as evidence that the app actually ran.  They are
not needed in order to run it.

5. NOTES
----------------------------------------------------------------------

Both scripts end with app.run() and therefore both listen on port 8050.
Run them ONE AT A TIME (Ctrl+C between runs), or change the last line of
the second script to  app.run(port=8051).

The single callback returns a list of five figures, in the same order as
the five Output(...) entries in the decorator.  That is the pattern the
module teaches: one input, many outputs, no duplicated callbacks.

----------------------------------------------------------------------
Prepared by LI Tianhao (MC663312) for CISC7204 Assignment 02,
University of Macau.  Due 25 October 2026, 11:00 pm.
----------------------------------------------------------------------